#pragma once

#ifndef STDAFX_H
#define STDAFX_H

#include <iostream>
#include <string>
#include <fstream>

#endif